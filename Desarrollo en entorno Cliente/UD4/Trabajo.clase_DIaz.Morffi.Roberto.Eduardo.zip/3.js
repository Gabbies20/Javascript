
console.log(numCifras(2000))


function numCifras(num){
    longitud = [...`${num}`].length;
   console.log(longitud)

}